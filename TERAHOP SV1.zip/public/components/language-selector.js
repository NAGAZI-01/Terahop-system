// Language Selector Component for TERAHOP
class LanguageSelector {
  constructor(containerId, options = {}) {
    this.container = document.getElementById(containerId);
    this.options = {
      showFlag: true,
      showNativeName: true,
      className: 'language-selector',
      ...options
    };
    this.currentLanguage = localStorage.getItem('terahop_language') || 'en';
    this.languages = [];
    
    this.init();
  }

  async init() {
    await this.loadLanguages();
    this.render();
    this.bindEvents();
  }

  async loadLanguages() {
    try {
      const response = await fetch('/api/languages');
      const data = await response.json();
      this.languages = data.languages;
    } catch (error) {
      console.error('Failed to load languages:', error);
      // Fallback languages
      this.languages = [
        { code: 'th', name: 'ภาษาไทย', nativeName: 'ภาษาไทย', flag: '🇹🇭' },
        { code: 'en', name: 'English', nativeName: 'English', flag: '🇬🇧' },
        { code: 'zh-CN', name: 'Chinese (Simplified)', nativeName: '简体中文', flag: '🇨🇳' },
        { code: 'zh-TW', name: 'Chinese (Traditional)', nativeName: '繁體中文', flag: '🇹🇼' }
      ];
    }
  }

  render() {
    if (!this.container) return;

    const selectorHTML = `
      <div class="${this.options.className}">
        <button class="language-toggle" aria-label="Select language">
          ${this.renderCurrentLanguage()}
        </button>
        <div class="language-dropdown" style="display: none;">
          ${this.renderLanguageOptions()}
        </div>
      </div>
    `;

    this.container.innerHTML = selectorHTML;
  }

  renderCurrentLanguage() {
    const current = this.languages.find(lang => lang.code === this.currentLanguage) || this.languages[0];
    let html = '';
    
    if (this.options.showFlag) {
      html += `<span class="flag">${current.flag}</span>`;
    }
    
    html += `<span class="name">${current.nativeName}</span>`;
    html += `<svg class="arrow" width="12" height="12" viewBox="0 0 12 12" fill="none">
      <path d="M3 4.5L6 7.5L9 4.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>`;
    
    return html;
  }

  renderLanguageOptions() {
    return this.languages.map(lang => `
      <button 
        class="language-option ${lang.code === this.currentLanguage ? 'active' : ''}" 
        data-lang="${lang.code}"
        aria-label="Switch to ${lang.name}"
      >
        ${this.options.showFlag ? `<span class="flag">${lang.flag}</span>` : ''}
        <div class="language-info">
          <span class="native-name">${lang.nativeName}</span>
          ${this.options.showNativeName && lang.name !== lang.nativeName ? 
            `<span class="english-name">${lang.name}</span>` : ''}
        </div>
        ${lang.code === this.currentLanguage ? 
          `<svg class="check" width="16" height="16" viewBox="0 0 16 16" fill="none">
            <path d="M13.5 4.5L6 12L2.5 8.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>` : ''}
      </button>
    `).join('');
  }

  bindEvents() {
    const toggle = this.container.querySelector('.language-toggle');
    const dropdown = this.container.querySelector('.language-dropdown');
    const options = this.container.querySelectorAll('.language-option');

    // Toggle dropdown
    if (toggle) {
      toggle.addEventListener('click', (e) => {
        e.stopPropagation();
        const isVisible = dropdown.style.display !== 'none';
        dropdown.style.display = isVisible ? 'none' : 'block';
        toggle.setAttribute('aria-expanded', !isVisible);
      });
    }

    // Select language
    options.forEach(option => {
      option.addEventListener('click', (e) => {
        e.stopPropagation();
        const lang = option.dataset.lang;
        this.selectLanguage(lang);
      });
    });

    // Close dropdown when clicking outside
    document.addEventListener('click', (e) => {
      if (!this.container.contains(e.target)) {
        dropdown.style.display = 'none';
        toggle.setAttribute('aria-expanded', 'false');
      }
    });

    // Keyboard navigation
    this.container.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        dropdown.style.display = 'none';
        toggle.setAttribute('aria-expanded', 'false');
        toggle.focus();
      }
    });
  }

  async selectLanguage(languageCode) {
    try {
      // Save language preference
      localStorage.setItem('terahop_language', languageCode);
      
      // Update current language
      this.currentLanguage = languageCode;
      
      // Update UI
      this.render();
      this.bindEvents();
      
      // Load new translations
      if (typeof window.i18n !== 'undefined') {
        await window.i18n.setLanguage(languageCode);
      }
      
      // Notify server of language change
      await fetch('/api/language', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ language: languageCode })
      });
      
      // Show success message
      this.showNotification('Language changed successfully');
      
    } catch (error) {
      console.error('Failed to change language:', error);
      this.showNotification('Failed to change language', 'error');
    }
  }

  showNotification(message, type = 'success') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `language-notification ${type}`;
    notification.textContent = message;
    
    // Style the notification
    Object.assign(notification.style, {
      position: 'fixed',
      top: '20px',
      right: '20px',
      padding: '12px 20px',
      backgroundColor: type === 'success' ? '#10b981' : '#ef4444',
      color: 'white',
      borderRadius: '8px',
      fontSize: '14px',
      fontWeight: '500',
      boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
      zIndex: '9999',
      opacity: '0',
      transform: 'translateY(-10px)',
      transition: 'all 0.3s ease'
    });
    
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
      notification.style.opacity = '1';
      notification.style.transform = 'translateY(0)';
    }, 100);
    
    // Remove after 3 seconds
    setTimeout(() => {
      notification.style.opacity = '0';
      notification.style.transform = 'translateY(-10px)';
      setTimeout(() => {
        if (notification.parentNode) {
          notification.parentNode.removeChild(notification);
        }
      }, 300);
    }, 3000);
  }

  // Public method to get current language
  getCurrentLanguage() {
    return this.currentLanguage;
  }

  // Public method to set language programmatically
  async setLanguage(languageCode) {
    if (this.languages.find(lang => lang.code === languageCode)) {
      await this.selectLanguage(languageCode);
    }
  }
}

// Auto-initialize language selectors
document.addEventListener('DOMContentLoaded', () => {
  // Find all elements with data-language-selector attribute
  const selectors = document.querySelectorAll('[data-language-selector]');
  selectors.forEach(element => {
    const containerId = element.getAttribute('data-language-selector');
    new LanguageSelector(containerId);
  });
});

// Export for use in other modules
if (typeof window !== 'undefined') {
  window.LanguageSelector = LanguageSelector;
}