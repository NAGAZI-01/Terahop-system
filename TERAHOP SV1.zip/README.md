# 🌐 TERAHOP Online Server

ระบบเช็คเวลาและจัดการพนักงานที่ทำงานบนเครือข่ายและอินเทอร์เน็ต

## 🚀 การติดตั้งและรัน Online Server

### 1. ติดตั้ง Dependencies
```bash
npm install
```

### 2. รัน Server แบบ Local Network (คนในออฟฟิศ/องค์กร)
```bash
npm start
```
Server จะทำงานบนเครือข่ายภายใน (LAN) - คนในเครือข่ายเดียวกันเข้าถึงได้

### 3. รัน Server แบบ Online (ทุกคนเข้าถึงได้จากอินเทอร์เน็ต)
```bash
node start-online.js
```
จะใช้ ngrok สร้าง URL สาธารณะให้เข้าถึงได้จากอินเทอร์เน็ตทั่วโลก

## 📱 การเข้าถึง

### Local Network (คนในออฟฟิศ):
- http://localhost:3000
- http://[YOUR_IP]:3000 (คนในเครือข่ายเดียวกัน)

### Internet (ทุกคนที่มีอินเทอร์เน็ต):
- https://[RANDOM-WORDS].ngrok.io (URL จาก ngrok - จะแสดงตอนรัน server)

## 🔧 การตั้งค่าเพิ่มเติม

### เปลี่ยน Port:
```bash
PORT=8080 npm start
```

### ใช้งานบน Production:
```bash
NODE_ENV=production npm start
```

### ตั้งค่า CORS สำหรับความปลอดภัย:
```bash
CORS_ORIGIN=https://yourdomain.com npm start
```

## 📊 หน้าต่างๆ ที่สามารถเข้าถึง:

| หน้า | URL | ฟังก์ชัน |
|------|-----|-----------|
| หน้าหลัก | `/` | ระบบเช็คเวลาเข้า-ออกงาน |
| เพิ่มพนักงาน | `/batch` | จัดการพนักงานแบบกลุ่ม |
| อ่านข้อมูล | `/read-batch` | อัปโหลดข้อมูล batch |
| บันทึกกิจกรรม | `/read-index` | บันทึกกิจกรรมพนักงาน |
| Health Check | `/api/health` | ตรวจสอบสถานะ server |
| Server Info | `/api/server-info` | ข้อมูลเซิร์ฟเวอร์ |

## 🌍 การใช้งานบนอินเทอร์เน็ต

### วิธีที่ 1: แชร์ให้คนในองค์กร
1. รัน server: `npm start`
2. ดู IP address ที่แสดงใน console
3. แชร์ `http://[IP]:3000` ให้คนในองค์กร

### วิธีที่ 2: แชร์ให้คนข้างนอก (อินเทอร์เน็ต)
1. รัน: `node start-online.js`
2. รอ 10-15 วินาที จะมี URL จาก ngrok แสดง
3. คัดลอก URL ที่ได้ (เช่น: `https://abc123.ngrok.io`)
4. แชร์ URL นี้ให้คนอื่นเข้าใช้งาน

### วิธีที่ 3: ใช้ Service อื่น
```bash
# ใช้ Cloudflare Tunnel
cloudflared tunnel --url http://localhost:3000

# หรือใช้ localtunnel
npx localtunnel --port 3000
```

## 📱 การเข้าถึงจากมือถือ

### WiFi เดียวกัน:
- เปิดเบราว์เซอร์บนมือถือ
- พิมพ์: `http://[IP_COMPUTER]:3000`

### ผ่านอินเทอร์เน็ต:
- ใช้ URL จาก ngrok ที่ได้จากขั้นตอนที่ 2

## 🔒 ความปลอดภัย

- ✅ Server ใช้ CORS protection
- ✅ มี helmet middleware สำหรับ security
- ✅ สามารถตั้งค่า CORS_ORIGIN ใน .env file
- ✅ รองรับ HTTPS ผ่าน tunneling services
- ⚠️ **ข้อแนะนำ:** สำหรับการใช้งานจริง ควรใช้ authentication

## 🛠️ การบำรุงรักษา

### ตรวจสอบสถานะ Server:
```bash
curl http://localhost:3000/api/health
```

### ดู Logs:
```bash
# ถ้ารันด้วย PM2
pm2 logs terahop-online

# หรือดู logs ใน console
```

### Restart Server:
```bash
# ถ้าใช้ PM2
pm2 restart terahop-online

# หรือหยุดแล้วเริ่มใหม่
Ctrl+C
npm start
```

## 🎯 สถานการณ์การใช้งาน

### 1. ออฟฟิศ/โรงงาน:
```bash
npm start
# แชร์ IP address ให้คนในองค์กร
```

### 2. ทำงานระยะไกล:
```bash
node start-online.js
# แชร์ ngrok URL ให้ทีมงาน
```

### 3. การทดสอบกับลูกค้า:
```bash
node start-online.js
# แชร์ URL ให้ลูกค้าทดลองใช้งาน
```

## 🚨 การแก้ปัญหา

### Port ถูกใช้งาน:
```bash
# หา process ที่ใช้ port 3000
lsof -i :3000

# เปลี่ยน port
PORT=8080 npm start
```

### ไม่สามารถเข้าจากเครือข่ายภายใน:
- ตรวจสอบ Windows Firewall
- ตรวจสอบ Antivirus settings
- ตรวจสอบ Router settings

### Ngrok ไม่ทำงาน:
```bash
# ติดตั้งใหม่
npm install ngrok@5.0.0 --no-save

# หรือใช้ alternative
npx localtunnel --port 3000
```

## 📦 การเตรียมไฟล์สำหรับ Deployment

1. Zip โฟลเดอร์ `terahop-server`
2. อัปโหลดไปยัง server จริง
3. ทำตามขั้นตอนการติดตั้ง

---

**🎉 TERAHOP Online Server พร้อมให้ทุกคนเข้าใช้งานแล้ว!**

**📞 ต้องการความช่วยเหลือ:** ดู console logs หรือติดต่อผู้พัฒนา