// Language configuration for TERAHOP multilingual support
const languages = {
  'th': {
    name: 'ภาษาไทย',
    nativeName: 'ภาษาไทย',
    flag: '🇹🇭',
    dir: 'ltr',
    dateFormat: 'DD/MM/YYYY',
    timeFormat: 'HH:mm',
    fallback: false
  },
  'en': {
    name: 'English',
    nativeName: 'English',
    flag: '🇬🇧',
    dir: 'ltr',
    dateFormat: 'MM/DD/YYYY',
    timeFormat: 'hh:mm A',
    fallback: true // Default fallback language
  },
  'zh-CN': {
    name: 'Chinese (Simplified)',
    nativeName: '简体中文',
    flag: '🇨🇳',
    dir: 'ltr',
    dateFormat: 'YYYY-MM-DD',
    timeFormat: 'HH:mm',
    fallback: false
  },
  'zh-TW': {
    name: 'Chinese (Traditional)',
    nativeName: '繁體中文',
    flag: '🇹🇼',
    dir: 'ltr',
    dateFormat: 'YYYY/MM/DD',
    timeFormat: 'HH:mm',
    fallback: false
  }
};

// Get default language
const getDefaultLanguage = () => {
  return 'en'; // English as default
};

// Get language by browser preference
const getBrowserLanguage = () => {
  const browserLang = navigator.language || navigator.userLanguage;
  
  // Map browser language codes to our supported languages
  const langMap = {
    'th': 'th',
    'th-TH': 'th',
    'en': 'en',
    'en-US': 'en',
    'en-GB': 'en',
    'zh': 'zh-CN',
    'zh-CN': 'zh-CN',
    'zh-TW': 'zh-TW',
    'zh-HK': 'zh-TW'
  };
  
  return langMap[browserLang] || getDefaultLanguage();
};

// Get supported language codes
const getSupportedLanguages = () => {
  return Object.keys(languages);
};

// Get language info
const getLanguageInfo = (langCode) => {
  return languages[langCode] || languages[getDefaultLanguage()];
};

// Check if language is supported
const isLanguageSupported = (langCode) => {
  return languages.hasOwnProperty(langCode);
};

// Get fallback language
const getFallbackLanguage = () => {
  const fallbackLang = Object.keys(languages).find(key => languages[key].fallback);
  return fallbackLang || 'en';
};

module.exports = {
  languages,
  getDefaultLanguage,
  getBrowserLanguage,
  getSupportedLanguages,
  getLanguageInfo,
  isLanguageSupported,
  getFallbackLanguage
};