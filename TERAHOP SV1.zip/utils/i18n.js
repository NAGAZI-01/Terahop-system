// Internationalization (i18n) utility for TERAHOP
const { 
  getDefaultLanguage, 
  getBrowserLanguage, 
  getSupportedLanguages,
  getLanguageInfo,
  isLanguageSupported,
  getFallbackLanguage 
} = require('../config/languages');

class I18n {
  constructor() {
    this.currentLanguage = this.getStoredLanguage() || getBrowserLanguage();
    this.translations = {};
    this.loadTranslations(this.currentLanguage);
  }

  // Get stored language from localStorage
  getStoredLanguage() {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('terahop_language');
    }
    return null;
  }

  // Store language preference
  setStoredLanguage(lang) {
    if (typeof window !== 'undefined') {
      localStorage.setItem('terahop_language', lang);
    }
  }

  // Load translations for a specific language
  async loadTranslations(language) {
    if (!isLanguageSupported(language)) {
      console.warn(`Language ${language} not supported, falling back to ${getDefaultLanguage()}`);
      language = getDefaultLanguage();
    }

    try {
      const response = await fetch(`/translations/${language}.json`);
      if (!response.ok) {
        throw new Error(`Failed to load translations for ${language}`);
      }
      this.translations = await response.json();
      this.currentLanguage = language;
      this.setStoredLanguage(language);
    } catch (error) {
      console.error('Error loading translations:', error);
      // Fallback to default language
      if (language !== getDefaultLanguage()) {
        await this.loadTranslations(getDefaultLanguage());
      }
    }
  }

  // Get translation for a key
  t(key, params = {}) {
    const keys = key.split('.');
    let translation = this.translations;

    for (const k of keys) {
      if (translation && translation[k]) {
        translation = translation[k];
      } else {
        // Fallback to default language if key not found
        if (this.currentLanguage !== getDefaultLanguage()) {
          console.warn(`Translation key "${key}" not found in ${this.currentLanguage}, checking fallback`);
          const fallbackTranslation = this.getFallbackTranslation(key);
          if (fallbackTranslation) {
            return this.interpolate(fallbackTranslation, params);
          }
        }
        return key; // Return key if no translation found
      }
    }

    return this.interpolate(translation, params);
  }

  // Get translation from fallback language
  getFallbackTranslation(key) {
    // This would need access to fallback translations
    // For now, return the key
    return key;
  }

  // Interpolate parameters into translation string
  interpolate(text, params) {
    if (typeof text !== 'string') {
      return text;
    }

    return text.replace(/\{(\w+)\}/g, (match, key) => {
      return params[key] !== undefined ? params[key] : match;
    });
  }

  // Change current language
  async setLanguage(language) {
    if (isLanguageSupported(language)) {
      await this.loadTranslations(language);
      this.updateDocumentLanguage();
      this.updatePageContent();
      return true;
    }
    return false;
  }

  // Get current language
  getCurrentLanguage() {
    return this.currentLanguage;
  }

  // Get supported languages
  getSupportedLanguages() {
    return getSupportedLanguages().map(lang => ({
      code: lang,
      ...getLanguageInfo(lang)
    }));
  }

  // Update document language attribute
  updateDocumentLanguage() {
    if (typeof document !== 'undefined') {
      document.documentElement.lang = this.currentLanguage;
      const langInfo = getLanguageInfo(this.currentLanguage);
      document.documentElement.dir = langInfo.dir || 'ltr';
    }
  }

  // Update page content with new language
  updatePageContent() {
    if (typeof document !== 'undefined') {
      // Update page title
      const title = this.t('app.title');
      if (title && title !== 'app.title') {
        document.title = title;
      }

      // Update all elements with data-i18n attribute
      const elements = document.querySelectorAll('[data-i18n]');
      elements.forEach(element => {
        const key = element.getAttribute('data-i18n');
        const translation = this.t(key);
        
        if (translation && translation !== key) {
          if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
            element.placeholder = translation;
          } else {
            element.textContent = translation;
          }
        }
      });

      // Update elements with data-i18n-attr attribute for attributes
      const attrElements = document.querySelectorAll('[data-i18n-attr]');
      attrElements.forEach(element => {
        const attrConfig = element.getAttribute('data-i18n-attr');
        const [attr, key] = attrConfig.split(':');
        const translation = this.t(key);
        
        if (translation && translation !== key) {
          element.setAttribute(attr, translation);
        }
      });

      // Trigger custom event for language change
      document.dispatchEvent(new CustomEvent('languageChanged', {
        detail: { language: this.currentLanguage }
      }));
    }
  }

  // Format date according to current language
  formatDate(date, format = 'date') {
    if (!date) return '';

    const d = new Date(date);
    const langInfo = getLanguageInfo(this.currentLanguage);
    
    try {
      if (format === 'date') {
        return d.toLocaleDateString(this.currentLanguage.replace('-', '-'));
      } else if (format === 'time') {
        return d.toLocaleTimeString(this.currentLanguage.replace('-', '-'));
      } else if (format === 'datetime') {
        return d.toLocaleString(this.currentLanguage.replace('-', '-'));
      }
    } catch (error) {
      console.error('Date formatting error:', error);
      return d.toLocaleDateString(); // Fallback
    }
    
    return d.toLocaleDateString();
  }

  // Format number according to current language
  formatNumber(number, options = {}) {
    if (typeof number !== 'number') return number;
    
    try {
      return number.toLocaleString(this.currentLanguage.replace('-', '-'), options);
    } catch (error) {
      console.error('Number formatting error:', error);
      return number.toString(); // Fallback
    }
  }

  // Format currency according to current language
  formatCurrency(amount, currency = 'THB') {
    return this.formatNumber(amount, {
      style: 'currency',
      currency: currency
    });
  }
}

// Create singleton instance
const i18n = new I18n();

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
  module.exports = i18n;
} else if (typeof window !== 'undefined') {
  window.i18n = i18n;
}

// Auto-initialize when DOM is ready
if (typeof document !== 'undefined') {
  document.addEventListener('DOMContentLoaded', () => {
    i18n.updateDocumentLanguage();
    i18n.updatePageContent();
  });
}